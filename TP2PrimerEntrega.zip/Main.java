import entidades.Estadio;
import service.ServiceEstadio;
import service.ServiceException;

public class Main {
    public static void main(String[] args) {
        Estadio estadio = new Estadio("Estadio Monumental", "Av. Figueroa Alcorta 7597", 70000);
        ServiceEstadio serviceEstadio = new ServiceEstadio();

        try {
            serviceEstadio.insertar(estadio);
            System.out.println("Estadio insertado correctamente");
        }
        catch (ServiceException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}