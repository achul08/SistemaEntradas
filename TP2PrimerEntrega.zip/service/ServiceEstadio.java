package service;

import dao.DaoEstadio;
import dao.DaoException;
import entidades.Estadio;
import java.util.List;

public class ServiceEstadio {
    private DaoEstadio daoEstadio;

    public ServiceEstadio() {
        daoEstadio = new DaoEstadio();
    }

    public void insertar(Estadio estadio) throws ServiceException {
        try {
            daoEstadio.insertar(estadio);
        }
        catch (DaoException e) {
            throw new ServiceException("Error en base de datos");
        }
    }
}
